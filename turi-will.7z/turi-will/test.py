#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec  8 21:09:57 2019

@author: willwang
"""
import turicreate as tc
tc.visualization.set_target('gui')
# Load the data
test_data =  tc.SFrame('test.sframe')

# Make a train-test split
#train_data, test_data = data.random_split(0.8)

model = tc.load_model('mymodel_will.model')

predictions = model.predict(test_data)

test_data['image_with_predictions'] = \
    tc.object_detector.util.draw_bounding_boxes(test_data['image'],predictions)

test_data[['image', 'image_with_predictions']].explore()